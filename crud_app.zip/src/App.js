import React, { useState } from "react";
import {
  BrowserRouter as Router,
  Routes,
  Route,
  useNavigate,
} from "react-router-dom";
import { Form, Input, Button, Checkbox, Typography, message } from "antd";
import { UserOutlined, LockOutlined } from "@ant-design/icons";
import "./App.css";
import UserList from "./UserList";

const { Title } = Typography;

function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [rememberMe, setRememberMe] = useState(false);
  const navigate = useNavigate();

  const handleLogin = () => {
    const credentials = {
      email: "eve.holt@reqres.in",
      password: "cityslicka",
    };

    if (email === credentials.email && password === credentials.password) {
      message.success("Login successful!");
      if (rememberMe) {
        localStorage.setItem("email", email);
      }
      navigate("/userlist");
    } else {
      message.error("Invalid email or password. Please try again.");
    }
  };

  return (
    <div className="App">
      <Form className="login-form" onFinish={handleLogin} layout="vertical">
        <Title level={2} style={{ textAlign: "center" }}>
          Login
        </Title>

        {/* Email Input */}
        <Form.Item
          name="email"
          rules={[
            { required: true, message: "Please enter your email!" },
            { type: "email", message: "Please enter a valid email!" },
          ]}
        >
          <Input
            prefix={<UserOutlined />}
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </Form.Item>

        {/* Password Input */}
        <Form.Item
          name="password"
          rules={[{ required: true, message: "Please enter your password!" }]}
        >
          <Input.Password
            prefix={<LockOutlined />}
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </Form.Item>

        {/* Remember Me Checkbox */}
        <Form.Item name="rememberMe" valuePropName="checked">
          <Checkbox
            checked={rememberMe}
            onChange={() => setRememberMe(!rememberMe)}
          >
            Remember Me
          </Checkbox>
        </Form.Item>

        {/* Login Button */}
        <Form.Item>
          <Button type="primary" htmlType="submit" block>
            Login
          </Button>
        </Form.Item>
      </Form>
    </div>
  );
}

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Login />} />
        <Route path="/userlist" element={<UserList />} />
      </Routes>
    </Router>
  );
}

export default App;
