import React, { useState, useEffect } from "react";
import {
  Table,
  Input,
  Button,
  Modal,
  Form,
  Avatar,
  Card,
  Row,
  Col,
} from "antd";
import {
  SearchOutlined,
  TableOutlined,
  UnorderedListOutlined,
  EditOutlined,
  DeleteOutlined,
} from "@ant-design/icons";

const UserList = () => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [form] = Form.useForm();
  const [editingUser, setEditingUser] = useState(null);
  const [viewMode, setViewMode] = useState("list");

  useEffect(() => {
    fetch("https://reqres.in/api/users?page=2")
      .then((response) => response.json())
      .then((data) => {
        setUsers(data.data);
        setLoading(false);
      })
      .catch(() => {
        setError("Failed to fetch users");
        setLoading(false);
      });
  }, []);

  const showModal = () => {
    setEditingUser(null);
    form.resetFields();
    setIsModalVisible(true);
  };

  const handleCancel = () => {
    setIsModalVisible(false);
  };

  const handleSearch = (event) => {
    setSearchQuery(event.target.value);
  };

  const handleSubmit = () => {
    form
      .validateFields()
      .then((values) => {
        if (editingUser) {
          const updatedUsers = users.map((user) =>
            user.id === editingUser.id
              ? { ...user, ...values, avatar: values.profile_image }
              : user
          );
          setUsers(updatedUsers);
        } else {
          setUsers([
            ...users,
            { ...values, id: users.length + 1, avatar: values.profile_image },
          ]);
        }
        setIsModalVisible(false);
      })
      .catch((info) => console.error("Validate Failed:", info));
  };

  const handleEdit = (user) => {
    setEditingUser(user);
    form.setFieldsValue({
      first_name: user.first_name,
      last_name: user.last_name,
      email: user.email,
      profile_image: user.avatar,
    });
    setIsModalVisible(true);
  };

  const handleDelete = (userId) => {
    const filteredUsers = users.filter((user) => user.id !== userId);
    setUsers(filteredUsers);
  };

  const filteredUsers = users.filter(
    (user) =>
      user.first_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.last_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.email.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const columns = [
    {
      title: "Avatar",
      dataIndex: "avatar",
      key: "avatar",
      render: (avatar) => <Avatar src={avatar} />,
    },
    {
      title: "Email",
      dataIndex: "email",
      key: "email",
    },
    {
      title: "First Name",
      dataIndex: "first_name",
      key: "first_name",
    },
    {
      title: "Last Name",
      dataIndex: "last_name",
      key: "last_name",
    },
    {
      title: "Actions",
      key: "actions",
      render: (_, user) => (
        <>
          <Button
            type="primary"
            onClick={() => handleEdit(user)}
            icon={<EditOutlined />}
            style={{ marginRight: "8px", padding: "0" }}
          />
          <Button
            type="primary"
            danger
            onClick={() => handleDelete(user.id)}
            icon={<DeleteOutlined />}
            style={{ padding: "0" }}
          />
        </>
      ),
    },
  ];

  return (
    <div style={{ padding: "20px" }}>
      <h1>User List</h1>

      <div
        style={{
          marginBottom: "20px",
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        <div>
          <Button
            onClick={() => setViewMode("list")}
            icon={<TableOutlined />}
            style={{ marginRight: "8px" }}
          />
          <Button
            onClick={() => setViewMode("card")}
            icon={<UnorderedListOutlined />}
            style={{ marginRight: "8px" }}
          />
        </div>

        <div style={{ display: "flex", gap: "10px" }}>
          <Input
            placeholder="Search users..."
            prefix={<SearchOutlined />}
            value={searchQuery}
            onChange={handleSearch}
            style={{ width: "300px" }}
          />
          <Button type="primary" onClick={showModal}>
            Create User
          </Button>
        </div>
      </div>

      {error ? (
        <div style={{ color: "red" }}>{error}</div>
      ) : viewMode === "list" ? (
        <Table
          columns={columns}
          dataSource={filteredUsers}
          rowKey="id"
          loading={loading}
        />
      ) : (
        <Row gutter={16}>
          {filteredUsers.map((user) => (
            <Col
              span={7} // Set the span to 7
              key={user.id}
              className="card-view"
              style={{ textAlign: "center" }}
            >
              <Card
                hoverable
                style={{
                  position: "relative",
                  display: "flex",
                  flexDirection: "column",
                  justifyContent: "center",
                  alignItems: "center",
                }}
                cover={<Avatar src={user.avatar} size={120} />}
              >
                <Card.Meta
                  title={`${user.first_name} ${user.last_name}`}
                  description={user.email}
                />

                {/* The Buttons container */}
                <div
                  className="card-actions"
                  style={{
                    position: "absolute",
                    bottom: "10px",
                    left: "50%",
                    transform: "translateX(-50%)",
                  }}
                >
                  <Button
                    type="primary"
                    onClick={() => handleEdit(user)}
                    icon={<EditOutlined />}
                    style={{ marginRight: "8px", padding: "0" }}
                  />
                  <Button
                    type="primary"
                    danger
                    onClick={() => handleDelete(user.id)}
                    icon={<DeleteOutlined />}
                    style={{ padding: "0" }}
                  />
                </div>
              </Card>
            </Col>
          ))}
        </Row>
      )}

      <Modal
        title={editingUser ? "Edit User" : "Create User"}
        visible={isModalVisible}
        onCancel={handleCancel}
        onOk={handleSubmit}
        okText="Submit"
        cancelText="Cancel"
      >
        <Form form={form} layout="vertical">
          <Form.Item
            label="First Name"
            name="first_name"
            rules={[{ required: true, message: "Please enter first name" }]}
          >
            <Input />
          </Form.Item>
          <Form.Item
            label="Last Name"
            name="last_name"
            rules={[{ required: true, message: "Please enter last name" }]}
          >
            <Input />
          </Form.Item>
          <Form.Item
            label="Email"
            name="email"
            rules={[
              { required: true, type: "email", message: "Invalid email" },
            ]}
          >
            <Input />
          </Form.Item>
          <Form.Item
            label="Profile Image URL"
            name="profile_image"
            rules={[
              { required: true, message: "Please enter profile image URL" },
            ]}
          >
            <Input />
          </Form.Item>
        </Form>
      </Modal>
    </div>
  );
};

export default UserList;
